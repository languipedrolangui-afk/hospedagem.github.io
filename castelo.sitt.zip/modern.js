// MODERN JAVASCRIPT FOR HOSPEDARIA CASTELO

document.addEventListener('DOMContentLoaded', function() {
    // ===== THEME TOGGLE =====
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = themeToggle.querySelector('i');
    
    themeToggle.addEventListener('click', function() {
        document.body.classList.toggle('light-theme');
        
        if (document.body.classList.contains('light-theme')) {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
            localStorage.setItem('theme', 'light');
        } else {
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
            localStorage.setItem('theme', 'dark');
        }
    });
    
    // Load saved theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        themeIcon.classList.remove('fa-moon');
        themeIcon.classList.add('fa-sun');
    }
    
    // ===== GLASS EFFECT ON SCROLL =====
    const glassNav = document.querySelector('.glass-nav');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            glassNav.style.background = 'rgba(10, 10, 10, 0.8)';
            glassNav.style.backdropFilter = 'blur(20px)';
        } else {
            glassNav.style.background = 'var(--bg-glass)';
            glassNav.style.backdropFilter = 'var(--glass-blur)';
        }
    });
    
    // ===== PARALLAX EFFECT =====
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('.parallax');
        
        parallaxElements.forEach(function(el) {
            const speed = el.dataset.speed || 0.5;
            el.style.transform = `translateY(${scrolled * speed}px)`;
        });
    });
    
    // ===== SMOOTH SCROLL =====
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // ===== ROOM IMAGE GALLERY =====
    const roomGalleryBtns = document.querySelectorAll('.room-gallery-btn');
    
    roomGalleryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const roomCard = this.closest('.room-card');
            const mainImage = roomCard.querySelector('.room-image img');
            const roomTitle = roomCard.querySelector('.room-title').textContent;
            
            // Create modal for image gallery
            createImageModal(mainImage.src, roomTitle);
        });
    });
    
    function createImageModal(imageSrc, title) {
        const modal = document.createElement('div');
        modal.className = 'image-modal';
        modal.innerHTML = `
            <div class="modal-backdrop"></div>
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <img src="${imageSrc}" alt="${title}">
                </div>
                <div class="modal-footer">
                    <button class="modal-prev"><i class="fas fa-chevron-left"></i></button>
                    <button class="modal-next"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Close modal
        modal.querySelector('.modal-backdrop').addEventListener('click', () => modal.remove());
        modal.querySelector('.modal-close').addEventListener('click', () => modal.remove());
        
        // Prevent body scroll
        document.body.style.overflow = 'hidden';
        
        // Cleanup on remove
        modal.addEventListener('animationend', function() {
            if (!document.body.contains(modal)) {
                document.body.style.overflow = '';
            }
        });
    }
    
    // ===== NEWSLETTER FORM =====
    const newsletterForm = document.getElementById('newsletterForm');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = this.querySelector('input[type="email"]').value;
            const button = this.querySelector('button');
            const originalText = button.innerHTML;
            
            // Show loading state
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
            button.disabled = true;
            
            // Simulate API call
            setTimeout(() => {
                // Success state
                button.innerHTML = '<i class="fas fa-check"></i> Inscrito!';
                button.style.background = 'var(--gradient-accent)';
                
                // Reset form
                this.reset();
                
                // Show success message
                const successMsg = document.createElement('div');
                successMsg.className = 'success-message';
                successMsg.textContent = 'Obrigado por se inscrever! Em breve você receberá nossas novidades.';
                this.appendChild(successMsg);
                
                // Remove message after 5 seconds
                setTimeout(() => {
                    successMsg.remove();
                    button.innerHTML = originalText;
                    button.disabled = false;
                    button.style.background = '';
                }, 5000);
            }, 1500);
        });
    }
    
    // ===== EXPERIENCE CARDS HOVER EFFECT =====
    const experienceCards = document.querySelectorAll('.experience-card');
    
    experienceCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            const image = this.querySelector('.experience-image img');
            image.style.transform = 'scale(1.1)';
        });
        
        card.addEventListener('mouseleave', function() {
            const image = this.querySelector('.experience-image img');
            image.style.transform = 'scale(1)';
        });
    });
    
    // ===== ANIMATE ON SCROLL =====
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe elements to animate
    document.querySelectorAll('.feature-card, .room-card, .experience-card, .testimonial-card').forEach(el => {
        observer.observe(el);
    });
    
    // ===== CURSOR EFFECT (Optional - remove if not needed) =====
    const cursor = document.querySelector('.cursor');
    const cursorFollower = document.querySelector('.cursor-follower');
    
    if (cursor && cursorFollower) {
        document.addEventListener('mousemove', function(e) {
            cursor.style.left = e.clientX + 'px';
            cursor.style.top = e.clientY + 'px';
            
            setTimeout(() => {
                cursorFollower.style.left = e.clientX + 'px';
                cursorFollower.style.top = e.clientY + 'px';
            }, 100);
        });
        
        // Interactive elements
        const interactiveElements = document.querySelectorAll('a, button, .room-gallery-btn, .nav-link');
        
        interactiveElements.forEach(el => {
            el.addEventListener('mouseenter', () => {
                cursor.style.transform = 'translate(-50%, -50%) scale(1.5)';
                cursorFollower.style.transform = 'translate(-50%, -50%) scale(2)';
            });
            
            el.addEventListener('mouseleave', () => {
                cursor.style.transform = 'translate(-50%, -50%) scale(1)';
                cursorFollower.style.transform = 'translate(-50%, -50%) scale(1)';
            });
        });
    }
    
    // ===== VIDEO BACKGROUND PLAYBACK =====
    const heroVideo = document.querySelector('.video-background video');
    
    if (heroVideo) {
        // Ensure video plays on mobile
        heroVideo.play().catch(error => {
            console.log('Video autoplay prevented:', error);
            // Show fallback image or play button
        });
        
        // Pause video when not visible for performance
        const videoObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    heroVideo.play();
                } else {
                    heroVideo.pause();
                }
            });
        }, { threshold: 0.5 });
        
        videoObserver.observe(heroVideo);
    }
    
    // ===== ROOM BOOKING QUICK ACTION =====
    const bookButtons = document.querySelectorAll('.btn-room-book, .btn-reservar-quarto');
    
    bookButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.href.includes('reservas.html')) {
                e.preventDefault();
                
                // Get room type from data attribute or parent
                const roomType = this.closest('.room-card') ? 
                    this.closest('.room-card').querySelector('.room-title').textContent : 
                    'Suite Vista Panorâmica';
                
                // Store in session storage for pre-fill
                sessionStorage.setItem('selectedRoom', roomType);
                
                // Redirect to booking page
                window.location.href = 'reservas.html';
            }
        });
    });
    
    // ===== COUNT UP ANIMATIONS =====
    const counters = document.querySelectorAll('.proof-value');
    
    counters.forEach(counter => {
        const target = parseFloat(counter.textContent);
        const suffix = counter.textContent.replace(/[0-9.]/g, '');
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const updateCounter = () => {
            current += step;
            if (current < target) {
                counter.textContent = Math.floor(current) + suffix;
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target + suffix;
            }
        };
        
        // Start when in view
        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    counterObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        counterObserver.observe(counter);
    });
});

// ===== SERVICE WORKER FOR PWA (Optional) =====
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').catch(error => {
            console.log('Service Worker registration failed:', error);
        });
    });
}